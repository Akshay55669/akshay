import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-container',
  templateUrl: './container.component.html',
  styleUrls: ['./container.component.css']
})
export class ContainerComponent implements OnInit {

  email=sessionStorage.getItem('email');

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  endSession()
  {
    sessionStorage.removeItem['email'];
    alert("Logged Out Successfully ")

    this.router.navigate(['/login'])
  }

}
