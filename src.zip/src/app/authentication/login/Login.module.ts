export class Login
{
    UserName:any;
    Password:any;
}