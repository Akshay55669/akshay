

export class Orders{


  Title:any;
  OrderName:any;
  OrderPrice:any;
  Price:any;
  Quantity:any;
  TotalPrice:any;
  OrderDate:Date;



}

